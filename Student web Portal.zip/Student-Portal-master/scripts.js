$(function(){
    $('#show_det').click(function(){
        $('#container').toggle()
    })
})